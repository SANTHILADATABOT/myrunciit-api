
        <!-- JS Page Level -->
        <!--[if (gte IE 9)|!(IE)]><!-->
		<script src="<?php echo base_url(); ?>template/front/js/share/jquery.share.js"></script>
        <!--<![endif]-->