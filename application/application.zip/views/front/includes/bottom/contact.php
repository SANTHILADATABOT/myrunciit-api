		

        <!-- JS Page Level -->
        <script src="<?php echo base_url(); ?>template/front/js/theme-ajax-mail.js"></script>
        <!--<![endif]-->