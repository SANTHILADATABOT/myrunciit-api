<link rel="stylesheet" href="<?php echo base_url(); ?>template/front/plugins/zoome/css/zoome-min.css" />
<script type="text/javascript" src="<?php echo base_url(); ?>template/front/plugins/zoome/zoome.js"></script>
<link href="<?php echo base_url(); ?>template/front/plugins/owl-carousel2/assets/owl.carousel.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>template/front/plugins/owl-carousel2/assets/owl.theme.default.min.css" rel="stylesheet">
