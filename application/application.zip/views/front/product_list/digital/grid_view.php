
                                <!-- Products grid -->
                                <div class="row products grid">
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-1c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-2c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-3c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-4c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-5c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-6c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-7c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-8c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-9c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-10c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-11c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-12c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-13c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-14c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6">
                                        <div class="thumbnail no-border no-padding">
                                            <div class="media">
                                                <a class="media-link" href="#">
                                                    <img src="<?php echo base_url(); ?>template/front/img/preview/shop/product-15c.jpg" alt=""/>
                                                    <span class="icon-view">
                                                        <strong><i class="fa fa-eye"></i></strong>
                                                    </span>
                                                </a>
                                            </div>
                                            <div class="caption text-center">
                                                <h4 class="caption-title">Standard Product Header</h4>
                                                <div class="rating">
                                                    <span class="star"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span><!--
                                                    --><span class="star active"></span>
                                                </div>
                                                <div class="price"><ins>$400.00</ins> <del>$425.00</del></div>
                                                <div class="buttons">
                                                    <a class="btn  btn-theme-transparent btn-wish-list" href="#"><i class="fa fa-heart"></i></a><!--
                                                    --><a class="btn  btn-theme-transparent btn-icon-left" href="#"><i class="fa fa-shopping-cart"></i>Add to Cart</a><!--
                                                    --><a class="btn  btn-theme-transparent btn-compare" href="#"><i class="fa fa-exchange"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /Products grid -->

                                <!-- Pagination -->
                                <div class="pagination-wrapper">
                                    <ul class="pagination">
                                        <li class="disabled"><a href="#"><i class="fa fa-angle-double-left"></i> Previous</a></li>
                                        <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
                                        <li><a href="#">2</a></li>
                                        <li><a href="#">3</a></li>
                                        <li><a href="#">4</a></li>
                                        <li><a href="#">Next <i class="fa fa-angle-double-right"></i></a></li>
                                    </ul>
                                </div>
                                <!-- /Pagination -->
