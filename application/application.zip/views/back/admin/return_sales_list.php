<div class="panel-body" id="demo_s">
    <table id="demo-table" class="table table-striped"  data-pagination="true" data-show-refresh="true"  data-show-toggle="true" data-show-columns="true" data-search="true" >

        <thead>
            <tr>
                <th style="width:4ex"><?php echo translate('ID');?></th>
                <th><?php echo translate('sale_code');?></th>
                <th><?php echo translate('order_id');?></th>
                <th><?php echo translate('buyer');?></th>
                <th><?php echo translate('date');?></th>
                
                <th><?php echo translate('return_reason');?></th>
                <th><?php echo translate('return_remarks');?></th>
                <th><?php echo translate('return_action');?></th>
                 <th class="text-right"><?php echo translate('options');?></th>
                
              
            </tr>
        </thead>
            
        <tbody>
        <?php
            $i = 0;
            foreach($all_sales as $row){
				//print_r($row);
            
                $i++;
        ?>
        <tr class="<?php if($row['viewed'] !== 'ok'){ echo 'pending'; } ?>" >
            <td><?php echo $i; ?></td>
            <td>#<?php echo $row['sale_code']; ?></td>
            <td>#<?php echo $row['order_id']; ?></td>
            <td><?php echo $this->crud_model->get_type_name_by_id('user',$row['buyer'],'username'); ?></td>
            <td><?php echo date('d-m-Y',$row['sale_datetime']); ?></td>
            
             <td><?php  echo $this->crud_model->get_type_name_by_id1('return_reason',$row['return_reason'],'return_reason'); ?></td>
              <td><?php echo $row['return_remarks']; ?></td>
                <td><?php if($row['return_action']==1) { ?> exchange <?php } else { ?>Refund <?php } ?></td>
             <td class="text-right">
          
	
                <a class="btn btn-info btn-xs btn-labeled fa fa-file-text" data-toggle="tooltip" 
                    onclick="ajax_set_full('view','<?php echo translate('title'); ?>','<?php echo translate('successfully_edited!'); ?>','sales_view','<?php echo $row['sale_id']; ?>')" 
                        data-original-title="Edit" data-container="body"><?php echo translate('full_invoice'); ?>
                </a>
                 <a class="btn btn-info btn-xs btn-labeled fa fa-file-text" href="<?php echo base_url(); ?>index.php/admin/return_sales/accept/<?php echo $row['sale_id']; ?>/<?php echo $row['return_action']; ?>"> <?php echo translate('accept'); ?>
                </a>
                 <a class="btn btn-info btn-xs btn-labeled fa fa-file-text" href="<?php echo base_url(); ?>index.php/admin/return_sales/decline/<?php echo $row['sale_id']; ?>"> <?php echo translate('decline'); ?>
                </a>
               
               
                
                
                
                
            </td>            
            
        </tr>
        <?php
                }
            
        ?>
        </tbody>
    </table>
</div>  
    <div id='export-div' style="padding:40px;">
        <h1 id ='export-title' style="display:none;"><?php echo translate('sales'); ?></h1>
        <table id="export-table" class="table" data-name='sales' data-orientation='l' data-width='1500' style="display:none;">
                <colgroup>
                    <col width="50">
                    <col width="150">
                    <col width="150">
                    <col width="150">
                    <col width="250">
                </colgroup>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Sale Code</th>
                        <th>Buyer</th>
                        <th>Date</th>
                        <th>Total</th>
                       
                    </tr>
                </thead>

                <tbody >
                <?php
                    $i = 0;
                    foreach($all_sales as $row){
                        if($this->crud_model->is_sale_of_vendor($row['sale_id'],$this->session->userdata('vendor_id'))){
                        $i++;
                ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td>#<?php echo $row['sale_code']; ?></td>
                    <td><?php echo $this->crud_model->get_type_name_by_id('user',$row['buyer'],'username'); ?></td>
                    <td><?php echo date('d-m-Y',$row['sale_datetime']); ?></td>
                    <td><?php echo currency('','def').$this->cart->format_number($this->crud_model->vendor_share_in_sale($row['sale_id'],$this->session->userdata('vendor_id'))['total']); ?></td>   
                    
                </tr>
                <?php
                        }
                    }
                ?>
                </tbody>
        </table>
    </div>
    
<style type="text/css">
    .pending{
        background: #D2F3FF  !important;
    }
    .pending:hover{
        background: #9BD8F7 !important;
    }
</style>



           