<div id="content-container">
	<div class="content-wrapper-before"></div>

	<div id="page-title">
		<h1 class="page-header text-overflow"><?php echo translate('manage_sale'); ?></h1>
	</div>
	<div class="tab-base">
		<div class="panel">
			<div class="panel-body">
				<div class="col-md-12" id="filterg" style="border-bottom: 1px solid #ebebeb;padding: 25px 5px 5px 5px;">
					<?php echo form_open(base_url() . 'index.php/admin/sales/', array(
						'class' => 'form-horizontal',
						'method' => 'post'
					));
					?>
					<div class="col-md-3">
						<?php echo $this->crud_model->select_html('vendor', 'vendor', 'name', 'edit', 'demo-chosen-select form-control', $vendor, '', '', '', '', '');  ?>
					</div>
					<div class="col-md-2">
						<select name="mode" class="form-control">
							<option value="0">All</option>
							<option value="pickup" <?php if ($mode == 'pickup') {
														echo 'selected="selected"';
													} ?>>Pickup</option>
							<option value="delivery" <?php if ($mode == 'delivery') {
															echo 'selected="selected"';
														} ?>>Delivery</option>
						</select>
					</div>
					<div class="col-md-2">
						<select name="pre_order_status" class="form-control">
							<option value="0">Pre Orders</option>
							<option value="ok" <?php if ($pre_order_status == 'ok') {
													echo 'selected="selected"';
												} ?>>Yes</option>
							<option value="no" <?php if ($pre_order_status == 'no') {
													echo 'selected="selected"';
												} ?>>No</option>
						</select>
					</div>
					<div class="col-md-2">
						<select name="delv_status" class="form-control">
							<option value="0">delivery status</option>
							<option value="delivered" <?php if ($delv_status == 'delivered') {
															echo 'selected="selected"';
														} ?>>Delivered</option>
							<option value="pending" <?php if ($delv_status == 'pending') {
														echo 'selected="selected"';
													} ?>>Pending</option>
							<option value="on_delivery" <?php if ($delv_status == 'on_delivery') {
															echo 'selected="selected"';
														} ?>>Out For Delivery</option>
						</select>
					</div>
					<div class="col-md-2">
						<select name="order_status" class="form-control">
							<option value="0">order status</option>
							<option value="success" <?php if ($order_status == 'success') {
														echo 'selected="selected"';
													} ?>>Accepted</option>
							<option value="admin_pending" <?php if ($order_status == 'admin_pending') {
																echo 'selected="selected"';
															} ?>>Waiting for accept</option>

						</select>
					</div>
					
					<div class="col-md-2">
						Start date:<input type="date" name="from" class="form-control" value="<?php echo $from ?>">
					</div>
					<div class="col-md-2">
						End date:<input type="date" name="to" class="form-control" value="<?php echo $to ?>">
					</div>
					
					<div class="col-md-2">
					<br>&nbsp;
						<button type="submit" class="btn btn-success">Filter</button>
					</div>



					</form>
				</div>
				<br>
				<!-- LIST -->
				<div class="tab-pane fade active in" id="list">

				</div>
			</div>
		</div>
	</div>
</div>

<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'sales';
	var list_cont_func = 'list/<?php if ($vendor) {
									echo $vendor;
								} else {
									echo "0";
								} ?>/<?php if ($from) {
			echo $from;
		} else {
			echo "0";
		} ?>/<?php if ($to) {
			echo $to;
		} else {
			echo "0";
		} ?>/<?php if ($mode) {
			echo $mode;
		} else {
			echo "0";
		} ?>/<?php if ($delv_status) {
			echo $delv_status;
		} else {
			echo "0";
		} ?>/<?php if ($order_status) {
			echo $order_status;
		} else {
			echo "0";
		} ?>/<?php if ($pre_order_status) {
			echo $pre_order_status;
		} else {
			echo "0";
		} ?>';
	var dlt_cont_func = 'delete';
</script>