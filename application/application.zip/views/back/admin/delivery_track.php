
<style>
.ors_fise .text-colr-lite{
	padding-left: 0;
}
.modal .text-colr-lite {
    padding-left: 0px;
}

.trk {
	background: #f7f7f7;
	padding: 15px 15px 25px;
}

._3BVwT {
	padding: 0px 10px;
	width: 100%;
}

._1i5nEe {
    display: inline-block;
    width: 0;
}
._1i5nEe {
    display: inline-block;
    width: 0;
    float: left;
}

._3HKlvX._31uEzM.active, ._1tBjl7.active {
    background: #0099e2;
}
._3HKlvX._31uEzM.active, ._1tBjl7.active {
    background: #0099e2;
}
._3HKlvX {
	border-radius: 50%;
	width: 20px;
	height: 20px;
	position: relative;
	cursor: pointer;
	background: #c9c9c9;
	top: -5px;
	z-index: 10;
	left: 13px;
}
._31uEzM, .aLqPfJ {
	background: #ccc;
	margin-bottom: 10px;
	margin-top: 21px;
}

._2QynGw {
	width: calc(100% - 10px);
	margin-left: -146px;
	margin-top: -29px;
	height: 8px;
	background: #ccc;
	margin-bottom: 21px;
}

._1tBjl7 {
	background: #c9c9c9;
	width: 164px;
	height: 8px;
	-webkit-transform: scaleX(0);
	transform: scaleX(0);
	-webkit-transform-origin: center left;
	transform-origin: center left;
	transition: -webkit-transform 1s ease-in;
	transition: transform 1s ease-in;
	transition: transform 1s ease-in, -webkit-transform 1s ease-in;
	transition-delay: 0s, 0s;
}

.detail_section {
	margin: 25px 0px 25px;
}

.fl-25 {
	float: left;
	width: 50%;
}

.fo-18 {
	font-size: 14px;
	font-weight: bold !important;
	color: #6a6a6a;
	margin-top: 5px;
	line-height: 25px;
}

.modal .text-colr-lite {
    padding-left: 0px;
}
.modal .text-colr-lite {
    padding-left: 0px;
}

.text-colr-lite {
    color: #333;
    text-transform: capitalize;
    padding-left: 15px;
}

.text-colr-lite {
    color: #333;
    text-transform: capitalize;
}

#view_track table th {
	text-align: center;
	background: #f7f7f7;
	color: #696969;
	border: 0;
}

#view_track table td {
    text-align: center;
    border: 0;
}

#view_track table td {
    text-align: center;
    border: 0;
}

._31uEzM:first-child{
    left:10px;
} 

.text-colr-lite{
    font-family: helvectica;
}

._3Qv1YL{
    line-height:20px;   
}

.modal-footer{
    display:none;
}
.diansgjfd5{
    width: 46%;
}
.dhkagjjh{
    width: 34.333%;
    
}


html {
  font-size: 62.5%;
}

body {
  color: #2c3e50;
  font-family: 'Montserrat', sans-serif;
  width: 40rem;
  font-weight: 300;
  min-height: 100vh;
  position: relative;
  display: block;
  margin: 2rem auto;
}

h2, h4, h6 {
  margin: 0;
  padding: 0;
  display: inline-block;
}

.root {
	padding: 1rem;
	border-radius: 0px;
	box-shadow: 0 1px 5px rgba(176, 176, 176, 0.3);
}

figure {
  display: flex;
}
figure img {
  width: 8rem;
  height: 8rem;
  border-radius: 15%;
  border: 1.5px solid #f05a00;
  margin-right: 1.5rem;
  padding:1rem;
}
figure figcaption {
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
}
figure figcaption h4 {
  font-size: 1.4rem;
  font-weight: 500;
}
figure figcaption h6 {
  font-size: 1rem;
  font-weight: 300;
}
figure figcaption h2 {
  font-size: 1.6rem;
  font-weight: 500;
}

.order-track {
	margin-top: 1rem;
	padding: 0 1rem;
	/* border-top: 1px dashed #2c3e50; */
	padding-top: 0.5rem;
	display: flex;
	flex-direction: column;
}
.order-track-step {
	display: flex;
	height: 11rem;
}
.order-track-step:last-child {
	overflow: hidden;
	height: 10rem;
}
.order-track-step:last-child .order-track-status span:last-of-type {
  display: none;
}
.order-track-status {
	margin-right: 1.5rem;
	position: relative;
	margin-top: 13px;
}
.order-track-status-dot {
	display: block;
	width: 2.2rem;
	height: 2.2rem;
	border-radius: 50%;
	background: linear-gradient(45deg,#4da7af,#65b3ba);
}
.order-track-status-line {
	display: block;
	margin: 0 auto;
	width: 2px;
	height: 9rem;
	background: linear-gradient(45deg,#4da7af,#65b3ba);
}
.order-track-text-stat {
  font-size: 1.3rem;
  font-weight: 500;
  margin-bottom: 3px;
}
.order-track-text-sub {
  font-size: 1rem;
  font-weight: 300;
}

.order-track {
  transition: all .3s height 0.3s;
  transform-origin: top center;
}

.prsjdfgsp_sdf {
	font-weight: 501;
	letter-spacing: 0.5px;
	font-size: 14px;
	color: #000;
}
.asdiohyiau {
	overflow-y: scroll;
	height: 226px;
	margin-bottom: 11px;
}
.zhgdcvkjh {
    color: #737373;
    font-size: 12px;
    font-weight: 501;
    letter-spacing: 0.5px;
    margin-bottom: 11px;
}

.dfhgs34dg{
    margin-bottom: 0px;
}
.fdhgdsghelement {
	border-bottom: 1px solid #ddd;
	margin-top: 0;
	padding-bottom: 15px;
}
</style>

<?php
//echo '<pre>'; print_r($trackdetail['tracking_data']); echo '</pre>';
$expectDate=strtotime($trackdetail['tracking_data']['edd']);
$shipment_track=$trackdetail['tracking_data']['shipment_track'][0];
$shipment_track_activities=$trackdetail['tracking_data']['shipment_track_activities'];
//echo '<pre>'; print_r($shipment_track); echo '</pre>';
$shipdet=$shipdet[0];
$trackDet=$this->db->get_where('shipment_track',array('order_id'=>$shipdet['order_id'],'shipment_id'=>$shipdet['shipping_id']))->result_array();  

$shipping_address=json_decode($shipdet['shipping_address'],1);
$shippingDet=$this->db->get_where('shipping',array('order_id'=>$order_id))->result_array();  
$shippingDet=$shippingDet[0];
$destination_branch=json_decode($shippingDet['destination_branch'],1);


?>
                         <div class="detail_section clearfix fdhgdsghelement">
                                                      <div class="fl-25">
                                                         <h2 class="fo-18">Status : <span class="text-colr fo-18"><?php echo $shipment_track['current_status']; ?></span></h2>
                                                         <p class="ml5"><strong class="text-colr-lite">Estimated Delivery Date </strong></p>
                                                         <p class="ml5"><span class="text-colr-lite"><?php echo date('l d F Y ', $expectDate); ?></span></p>
                                                         <?php
                                                         if($shippingDet['expected_delivery']!='')
                                                         {
                                                            ?>
                                                            <p class="ml5"><strong class="text-colr-lite">Delivered On :</strong> <span class="text-colr-lite"><?php echo  date('d D M Y h:i A',strtotime($shippingDet['delivered_date']));?></span></p>
                                                            <?php
                                                         }
                                                         ?>
                                                      </div>
                                                      <div class="fl-25">
                                                         <div class="fl-left">
                                                            <h2 class="fo-18">Shipping To :</h2>
                                                         </div>
                                                         <div class="fl-left ml-10">
                                                            <p class="text-colr-lite" style="margin-top: 8px;line-height: 18px;"><?php echo $shipping_address['firstname']?>,<span class="blockss"> <?php echo $shipping_address['address1']?>,</span><?php echo $shipping_address['address2']?>-<?php echo $shipping_address['zip']?>.<span class="blockss"> <?php echo $shipping_address['email']?>,</span><span class="blockss"> <?php echo $shipping_address['phone']?></span></p>
                                                         </div>
                                                      </div>
                                                   </div>
     
                             <section class="root asdiohyiau">
 
                              <div class="order-track">
                              <?php foreach($shipment_track_activities as $activites)
							  { ?>
                                <div class="order-track-step">
                                  <div class="order-track-status">
                                    <span class="order-track-status-dot"></span>
                                    <span class="order-track-status-line"></span>
                                  </div>
                                  <div class="order-track-text">
                                    <p class="order-track-text-stat zhgdcvkjh"><span class="prsjdfgsp_sdf">Activity : </span><?php echo $activites['activity']; ?></p>
                                     <p class="order-track-text-stat zhgdcvkjh dfhgs34dg"><span class="prsjdfgsp_sdf">Location : </span><?php echo $activites['location']; ?></p>
                                    <span class="order-track-text-sub"><?php echo date('d', strtotime($activites['date'])); ?>st <?php echo date('M, Y h:i A', strtotime($activites['date'])); ?></span>
                                  </div>
                                </div>
                              <?php } ?>
                                
                                
                              </div>
</section>  
                          
                           
                          
                          
                           
                           <div class="track_table clearfix">
                              <h2 class="fo-18 mtb-15">Shipment Track Details</h2>
                              <table class="table" cellpadding="0" cellspacing="0">
                                 <tr>
                                    <th>Consignee</th>
                                    <th>Origin</th>
                                    <th>Destination</th>
                                    <th>AWB Code</th>
                                    <th>Shipment ID</th>
                                    <th>Current Status</th>
                                 </tr>
                                 <?php foreach($trackdetail['tracking_data']['shipment_track'] as $ship) { 
								 ?>
                                 <tr>
                                    <td><?php echo $ship['consignee_name']; ?></td>
                                    <td><?php echo $ship['origin']; ?></td>
                                    <td><?php echo $ship['destination']; ?></td>
                                    <td><?php echo $ship['awb_code']; ?></td>
                                    <td><?php echo $ship['shipment_id']; ?></td>
                                    <td><?php echo $ship['current_status']; ?></td>
                                 </tr>
                                <?php }?>
                              </table>
                           </div>
