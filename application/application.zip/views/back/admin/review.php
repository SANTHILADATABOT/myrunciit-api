<div id="content-container">
<div class="content-wrapper-before"></div>

	<div id="page-title">
		<h1 class="page-header text-overflow"><?php echo translate('manage review & rating');?></h1>
	</div>
	<?php if ($this->session->flashdata('acc')) { ?>
    <div class="alert alert-success alert-dismissible show" role="alert">
       <?php echo $this->session->flashdata('acc') ?>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
          </button>
    </div>
<?php } ?>
<?php if ($this->session->flashdata('rej')) { ?>
    <div class="alert alert-danger alert-dismissible show" role="alert">
       <?php echo $this->session->flashdata('rej') ?>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
          </button>
    </div>
<?php } ?>
	<div class="tab-base">
		<div class="panel">
			<div class="panel-body">
				<div class="tab-content">
					<div class="col-md-12"></div>
					<br>
                    <!-- LIST -->
                    <div class="tab-pane fade active in" id="list" style="border:1px solid #ebebeb; border-radius:4px;">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'review';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
</script>
