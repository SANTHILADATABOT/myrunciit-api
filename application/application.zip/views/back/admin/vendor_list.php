<?php
$edit_rights=$user_rights_12_0['edit_rights'];
$delete_rights=$user_rights_12_0['delete_rights'];
?>
<div class="panel-body" id="demo_s">
    <table id="demo-table" class="table table-striped" data-pagination="true" data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true">
        <thead>
            <tr>
                <th><?php echo translate('logo'); ?></th>
                <th><?php echo translate('display_name'); ?></th>
                <th><?php echo translate('name'); ?></th>
                <th><?php echo translate('address'); ?></th>
                <th><?php echo translate('additional_store_information'); ?></th>
                <th><?php echo translate('pickup'); ?></th>
                <th><?php echo translate('delivery'); ?></th>
                <th><?php echo translate('phone'); ?></th>

                <th><?php echo translate('email'); ?></th>
                <th><?php echo translate('status'); ?></th>
                <th class="text-right"><?php echo translate('default_store'); ?></th>

                <th class="text-right"><?php echo translate('options'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 0;
            foreach ($all_vendors as $row) {
                $i++;
            ?>
                <tr>
                    <td>
                        <?php
                        if (file_exists('uploads/vendor_logo_image/logo_' . $row['vendor_id'] . '.png')) {
                        ?>
                            <img class="img-sm img-border" src="<?php echo base_url(); ?>uploads/vendor_logo_image/logo_<?php echo $row['vendor_id']; ?>.png" />
                        <?php
                        } else {
                        ?>
                            <img class="img-sm img-border" src="<?php echo base_url(); ?>uploads/vendor_logo_image/default.jpg" alt="">
                        <?php
                        }
                        ?>

                    </td>
                    <td><?php echo $row['display_name']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['address1'] . ',' . $row['city'] . ',' . $row['state'] . ',' . $row['country'] . ',' . $row['zip']; ?></td>
                    <td><?php echo "Delivery Zipcode " . $row['delivery_zipcode']; ?></td>
                    <td><?php if ($row['pickup'] == 'yes') { ?> <i class="fa fa-check" aria-hidden="true" style="color:green"></i>
                        <?php } else { ?><i class="fa fa-close" aria-hidden="true" style="color:red"></i>
                        <?php } ?> </td>
                    <td><?php if ($row['delivery'] == 'yes') { ?> <i class="fa fa-check" aria-hidden="true" style="color:green"></i>
                        <?php } else { ?><i class="fa fa-close" aria-hidden="true" style="color:red"></i>
                        <?php } ?> </td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td>
                        <div class="label label-<?php if ($row['status'] == 'approved') { ?>purple<?php } else { ?>danger<?php } ?>">
                            <?php echo $row['status']; ?>
                        </div>
                    </td>
                    <td>
                        <input class='aiz_switchery' type="checkbox" data-set='default_set' data-id='<?php echo $row['vendor_id']; ?>' data-tm='<?php echo translate('default_enabled'); ?>' data-fm='<?php echo translate('default_disabled'); ?>' <?php if ($row['default_set'] == 'ok') { ?>checked<?php } ?> />

                    </td>
                    <td class="text-right">
                        <a style="display:none;" class="btn btn-dark btn-xs btn-labeled fa fa-user" data-toggle="tooltip" onclick="ajax_modal('view','<?php echo translate('view_profile'); ?>','<?php echo translate('successfully_viewed!'); ?>','vendor_view','<?php echo $row['vendor_id']; ?>')" data-original-title="View" data-container="body">
                            <?php echo translate('profile'); ?>
                        </a>
                        <a class="btn btn-success btn-xs btn-labeled fa fa-check" data-toggle="tooltip" onclick="ajax_modal('approval','<?php echo translate('store_approval'); ?>','<?php echo translate('successfully_viewed!'); ?>','vendor_approval','<?php echo $row['vendor_id']; ?>')" data-original-title="View" data-container="body">
                            <?php
                            $commission_specific = $this->db->get_where('business_settings', array('type' => 'commission_type'))->row()->value;
                            if ($commission_specific == 'specific_vendor') {
                                echo translate('approval & commission');
                            } else {
                                echo translate('approval');
                            } ?>
                        </a>
                        <a style="display:none;" class="btn btn-info btn-xs btn-labeled fa fa-dollar" data-toggle="tooltip" onclick="ajax_modal('pay_form','<?php echo translate('pay_vendor'); ?>','<?php echo translate('successfully_viewed!'); ?>','vendor_pay','<?php echo $row['vendor_id']; ?>')" data-original-title="View" data-container="body">
                            <?php echo translate('pay'); ?>
                        </a>
                        <?php if($edit_rights=='1'){ ?>
                        <a class="btn btn-info btn-xs btn-labeled fa fa-dollar" data-toggle="tooltip" onclick="ajax_modal('edit','<?php echo translate('edit_store'); ?>','<?php echo translate('successfully_updated!'); ?>','vendor_edit','<?php echo $row['vendor_id']; ?>')" data-original-title="Edit" data-container="body">
                            <?php echo translate('Edit'); ?>
                        </a>
                        <?php } ?>
                        <?php if($delete_rights=='1'){ ?>
                        <a onclick="delete_confirm('<?php echo $row['vendor_id']; ?>','<?php echo translate('really_want_to_delete_this?'); ?>')" class="btn btn-xs btn-danger btn-labeled fa fa-trash" data-toggle="tooltip" data-original-title="Delete" data-container="body">
                            <?php echo translate('delete'); ?>
                        </a>
                        <?php } ?>
                        <a class="btn btn-xs btn-danger btn-labeled" onclick="setVendor('<?php echo $row['vendor_id'] ?>')" data-toggle="modal" data-target="#pickupHoursModal" data-vendorId="<?php echo $row['vendor_id'] ?>" data-original-title="Delete" data-container="body">
                            Pickup Slot
                        </a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>
<div class="modal fade" id="pickupHoursModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Pickup hours</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Available Days</th>
                            <th>Slot Start</th>
                            <th>Slot End</th>
                            <th>Interval In Minute</th>
                            <th>Max Order</th>
                            <th>Action</th>
                        </tr>

                    </thead>
                    <tbody id="pickupHourBody">

                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="addHour">Add Hours</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Pickup Slot</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <h1 class="card-title">Available Days</h1>
                        <form id="form3" method="post">

                            <div class="row " id="editModalBody">

                            </div>
                        </form>
                        <hr>
                        <h2>All fields compulsory unless marked optional</h2>
                        <form id="form2" method="post">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="editStartSlot">Pickup Slots Start At</label>
                                        <select class="form-control" name="startSlot" id="editStartSlot">
                                            <?php foreach ($timeList as $single) : ?>
                                                <option value="<?php echo $single['slot_start_time'] ?>"><?php echo $single['slot_start_time'] ?></option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="editSlotEnd">Pickup Slot End At</label>
                                        <select class="form-control" name="endSlot" id="editSlotEnd">
                                            <?php foreach ($timeList as $single) : ?>
                                                <option value="<?php echo $single['slot_start_time'] ?>"><?php echo $single['slot_start_time'] ?></option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                                <input type="hidden" name="interval_in_minute" value="60">

                                <!-- <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="editIntervel">Interval In Minutes</label>
                                        <select class="form-control" name="interval_in_minute" id="editIntervel">
                                            <option value="0">0</option>
                                            <option value="15">15</option>
                                            <option value="30">30</option>
                                            <option value="60">60</option>
                                            <option value="120">120</option>
                                        </select>
                                    </div>
                                </div> -->
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="editMaxOrder">Max Orders Per Slot</label>
                                        <input type="number" name="maxOrder" id="editMaxOrder" class="form-control" value="10">
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="updateBtn">Update</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="pickupDeliverySlotModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Pickup Slot</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <h1 class="card-title">Available Days</h1>
                        <form id="form1" method="post">

                            <div class="row " id="normalAvailableDaySection">
                                
                            </div>
                        </form>
                        <hr>
                        <h2>All fields compulsory unless marked optional</h2>
                        <form id="form2" method="post">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">Pickup Slots Start At</label>
                                        <select class="form-control" name="startSlot" id="exampleFormControlSelect1">
                                            <?php foreach ($timeList as $single) : ?>
                                                <option value="<?php echo $single['slot_start_time'] ?>"><?php echo $single['slot_start_time'] ?></option>
                                                <option value="<?php echo $single['slot_end_time'] ?>"><?php echo $single['slot_end_time'] ?></option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="exampleFormControlSelect2">Pickup Slot End At</label>
                                        <select class="form-control" name="endSlot" id="exampleFormControlSelect2">
                                            <?php foreach ($timeList as $single) : ?>
                                                <option value="<?php echo $single['slot_start_time'] ?>"><?php echo $single['slot_start_time'] ?></option>
                                                <option value="<?php echo $single['slot_end_time'] ?>"><?php echo $single['slot_end_time'] ?></option>
                                            <?php endforeach ?>
                                        </select>
                                    </div>
                                </div>
                                <input type="hidden" name="interval_in_minute" value="60">
                                <!-- <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="exampleFormControlSelect2">Interval In Minutes</label>
                                        <select class="form-control" name="interval_in_minute" id="exampleFormControlSelect2">
                                            <option value="0">0</option>
                                            <option value="15">15</option>
                                            <option value="30">30</option>
                                            <option value="60">60</option>
                                            <option value="120">120</option>
                                        </select>
                                    </div>
                                </div> -->
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="">Max Orders Per Slot</label>
                                        <input type="number" name="maxOrder" class="form-control" value="10">
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="saveForm">Save</button>
            </div>
        </div>
    </div>
</div>
<div id="vendr"></div>
<div id='export-div' style="padding:40px;">
    <h1 id='export-title' style="display:none;"><?php echo translate('vendors'); ?></h1>
    <table id="export-table" data-export-types="['excel','pdf']" data-show-export="true" class="table" data-name='vendors' data-orientation='p' data-width='1500' style="display:none;">
        <colgroup>
            <col width="300">
            <col width="300">
            <col width="300">
            <col width="300">
            <col width="300">
            <col width="300">
            <col width="300">
            <col width="300">
            <col width="300">
            <col width="300">
            <col width="300">
        </colgroup>
        <thead>
        <tr>
                <th><?php echo translate('logo'); ?></th>
                <th><?php echo translate('display_name'); ?></th>
                <th><?php echo translate('name'); ?></th>
                <th><?php echo translate('address'); ?></th>
                <th><?php echo translate('additional_store_information'); ?></th>
                <th><?php echo translate('pickup'); ?></th>
                <th><?php echo translate('delivery'); ?></th>
                <th><?php echo translate('phone'); ?></th>

                <th><?php echo translate('email'); ?></th>
                <th><?php echo translate('status'); ?></th>
                <th class="text-right"><?php echo translate('default_store'); ?></th>

            </tr>
        </thead>



        <tbody>
        <?php
            $i = 0;
            foreach ($all_vendors as $row) {
                $i++;
            ?>
                <tr>
                    <td>
                        <?php
                        if (file_exists('uploads/vendor_logo_image/logo_' . $row['vendor_id'] . '.png')) {
                        ?>
                            <img class="img-sm img-border" width="100" height="100" src="<?php echo base_url(); ?>uploads/vendor_logo_image/logo_<?php echo $row['vendor_id']; ?>.png" />
                        <?php
                        } else {
                        ?>
                            <img class="img-sm img-border" width="100" height="100" src="<?php echo base_url(); ?>uploads/vendor_logo_image/default.jpg" alt="">
                        <?php
                        }
                        ?>

                    </td>
                    <td><?php echo $row['display_name']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['address1'] . ',' . $row['city'] . ',' . $row['state'] . ',' . $row['country'] . ',' . $row['zip']; ?></td>
                    <td><?php echo "Delivery Zipcode " . $row['delivery_zipcode']; ?></td>
                    <td><?php if ($row['pickup'] == 'yes') { ?><i class="fa fa-check" aria-hidden="true" style="color:green"></i>
                        <?php } else { ?><i class="fa fa-close" aria-hidden="true" style="color:red"></i>
                        <?php } ?> </td>
                    <td><?php if ($row['delivery'] == 'yes') { ?><i class="fa fa-check" aria-hidden="true" style="color:green"></i>
                        <?php } else { ?><i class="fa fa-close" aria-hidden="true" style="color:red"></i>
                        <?php } ?> </td>
                    <td><?php echo $row['phone']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td>
                        <div class="label label-<?php if ($row['status'] == 'approved') { ?>purple<?php } else { ?>danger<?php } ?>">
                            <?php echo $row['status']; ?>
                        </div>
                    </td>
                    <td>
                        <input class='aiz_switchery' type="checkbox" data-set='default_set' data-id='<?php echo $row['vendor_id']; ?>' data-tm='<?php echo translate('default_enabled'); ?>' data-fm='<?php echo translate('default_disabled'); ?>' <?php if ($row['default_set'] == 'ok') { ?>checked<?php } ?> />

                    </td>
                    
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>
<script type="text/javascript">
    function set_switchery() {
        $(".aiz_switchery").each(function() {
            new Switchery($(this).get(0), {
                color: 'rgb(100, 189, 99)',
                secondaryColor: '#cc2424',
                jackSecondaryColor: '#c8ff77'
            });

            var changeCheckbox = $(this).get(0);
            var false_msg = $(this).data('fm');
            var true_msg = $(this).data('tm');
            changeCheckbox.onchange = function() {
                $.ajax({
                    url: base_url + 'index.php/admin/vendor/' + $(this).data('set') + '/' + $(this).data('id') + '/' + changeCheckbox.checked,
                    success: function(result) {
                        if (changeCheckbox.checked == true) {
                            $.activeitNoty({
                                type: 'success',
                                icon: 'fa fa-check',
                                message: true_msg,
                                container: 'floating',
                                timer: 3000
                            });
                            sound('published');
                        } else {
                            $.activeitNoty({
                                type: 'danger',
                                icon: 'fa fa-check',
                                message: false_msg,
                                container: 'floating',
                                timer: 3000
                            });
                            sound('unpublished');
                        }
                    }
                });
            };
        });
    }

    $(document).ready(function() {
        $('.demo-chosen-select').chosen();
        $('.demo-cs-multiselect').chosen({
            width: '100%'
        });
    });
</script>

<script>
    let vendorId = null;
    let pickupId = null;

    function setVendor(id) {
        vendorId = id;
        console.log('vendor', vendorId);
        // get pickup list according to vendor id
        const url = '<?php echo base_url('admin/getPickupDetailAsVendor') ?>';
        $.post(url, 'vendorId=' + vendorId, function(data) {

            $('#pickupHourBody').children().remove();
            let jsonData = JSON.parse(data);
            console.log('getPickupDetailAsVendor',jsonData);
            if (jsonData && jsonData.length > 0) {
                console.log('testing');
                jsonData.forEach(element => {

                    const availableDay = JSON.parse(element.available_days);
                    console.log('availableDay', availableDay);
                    $('#pickupHourBody').append(`
                    <tr>
                        <td class="text-center">${Object.keys(availableDay).map(function(el, ind1){
                            return availableDay[el] == 'on' ? el : '';
                        }).join(',').replace(/\,{2}/g,',')}</td>
                        <td class="text-center">${element.slot_start}</td>
                        <td class="text-center">${element.slot_end}</td>
                        <td class="text-center">${element.interval_in_minute}</td>
                        <td class="text-center">${element.max_order}</td>
                        <td>
                        <a class="btn btn-danger btn-xs btn-labeled " onclick="showEditModal(${element.id})">
                            <?php echo translate('Edit'); ?>
                        </a>
                        </td>
                    </tr>
                    `);
                });
            } else {
                $('#pickupHourBody').append(`
                    <tr>
                        <td>No Data</td>
                    </tr>
                    `);
            }
        }).fail(function(error) {
            console.log(error);
        })
    }

    function preferredOrder(obj, order) {
        var newObject = {};
        for (var i = 0; i < order.length; i++) {
            if (obj.hasOwnProperty(order[i])) {
                newObject[order[i]] = obj[order[i]];
            }
        }
        return newObject;
    }


    function showEditModal(pickupSlotId) {
        console.log('pickup id', pickupSlotId);
        pickupId = pickupSlotId;
        let daysArr = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
        let finalArr = [];
        const today = moment().tz('Asia/Kuala_Lumpur').format('ddd').toLowerCase();
        const getIndex = daysArr.indexOf(today);
        if (getIndex != 0) {
            const startSlicedArr = daysArr.slice(getIndex);
            const endSlicedArr = getIndex != 1 ? daysArr.slice(0, getIndex - 1) : [daysArr[0]];
            finalArr = [...startSlicedArr, ...endSlicedArr];
        } else {
            finalArr = daysArr;
        }
        const url = '<?php echo base_url('admin/getPickupDetail') ?>';
        $.post(url, 'pickupId=' + pickupSlotId, function(data) {
            const jsonData = JSON.parse(data);
            const availableData = JSON.parse(jsonData.available_days);
            console.log(jsonData);
            const formatedObj = preferredOrder(availableData, finalArr);
            console.log('formatedObj', formatedObj);
            $('#editModalBody').children().remove();
            for (const key in formatedObj) {
                if (Object.hasOwnProperty.call(formatedObj, key)) {
                    const element = formatedObj[key];
                    console.log(key);
                    $('#editModalBody').append(`
                    <div class="col-lg-1">
                        <input class="form-check-input" name="${key}" type="checkbox" ${element == 'on' ? 'checked' : ''}  id="inlineFormCheck${key}">
                        <label class="form-check-label" for="inlineFormCheck${key}">
                            ${key}
                        </label>
                    </div>
                    `);
                }
                $('#editStartSlot').val(jsonData.slot_start);
                $('#editSlotEnd').val(jsonData.slot_end);
                $('#editIntervel').val(jsonData.interval_in_minute);
                $('#editMaxOrder').val(jsonData.max_order);
            }
            $('#editModal').modal('show');

        }).fail(function(error) {
            console.log(error);
        })
    }
    $(document).ready(function() {

        $('#normalAvailableDaySection').children().remove();
        let daysArr = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
        let finalArr = [];
        const today = moment().tz('Asia/Kuala_Lumpur').format('ddd').toLowerCase();
        const getIndex = daysArr.indexOf(today);
        if (getIndex != 0) {
            const startSlicedArr = daysArr.slice(getIndex);
            const endSlicedArr = getIndex != 1 ? daysArr.slice(0, getIndex - 1) : [daysArr[0]];
            finalArr = [...startSlicedArr, ...endSlicedArr];
        } else {
            finalArr = daysArr;
        }
        finalArr.forEach(element => {
            $('#normalAvailableDaySection').append(`
                    <div class="col-lg-1">
                        <input class="form-check-input" name="${element}" type="checkbox" checked  id="inlineFormCheck${element}">
                        <label class="form-check-label" for="inlineFormCheck${element}">
                            ${element}
                        </label>
                    </div>
                    `);
        });
        
        $('#saveForm').click(function(e) {
            const slotStart = $('#exampleFormControlSelect1').val();
            const slotEnd = $('#exampleFormControlSelect2').val();
            if (slotStart == slotEnd) {
                alert('Please selected different end time');
                return;
            }
            const form1 = $('#form1').serialize();
            const form2 = $('#form2').serialize();

            e.preventDefault();
            console.log('form1', form1);
            console.log('form2', form2);
            const url = '<?php echo base_url('admin/saveFormData') ?>';
            $.post(url, form1 + '&' + form2 + '&vendorId=' + vendorId, function(data) {
                console.log(data);
                $('#pickupDeliverySlotModal').modal('hide');
            }).fail(function(error) {
                console.log(error);
            })
        });
        $('#updateBtn').click(function(e) {
            const slotStart = $('#editStartSlot').val();
            const slotEnd = $('#editSlotEnd').val();
            console.log('start slot', slotStart);
            console.log(' end slot', slotEnd);
            if (slotStart == slotEnd) {
                alert('Please selected different end time');
                return;
            }
            const form1 = $('#form3').serialize();
            const form2 = $('#form2').serialize();
            $('#pickupDeliverySlotModal').modal('hide');
            e.preventDefault();
            console.log('form1', form1);
            console.log('form2', form2);
            const url = '<?php echo base_url('admin/updateFormData') ?>';
            console.log(url);
            $.post(url, form1 + '&' + form2 + '&vendorId=' + vendorId + '&pickupId=' + pickupId, function(data) {
                console.log(data);
                $('#editModal').modal('hide');
                $('#pickupHoursModal').modal('hide');
            }).fail(function(error) {
                console.log(error);
            })
            
        });

        $('#addHour').click(function(e) {
            e.preventDefault();
            $('#pickupHoursModal').modal('hide');
            $('#pickupDeliverySlotModal').modal('show');
        })
    })
</script>