<?php 
/*use Twilio\Rest\Client; 
$to="+919659929960";
$msg='TEST';
class Twilio
{
function sendotp($to,$msg)
{
	
 echo "<pre>"; print_r(array($to,$msg)); echo "</pre>"; //exit;
require_once 'Twilio/autoload.php'; 

//$sid    = "AC2792b1671f6922f9cf17dbe56ac0107b"; 
$sid    = "AC0cb00021d7054df8989f004397adf52c";
//$token  = "1cef381629e66c4a8d44add723fdb4a1"; 
$token  = "af9b554af14f1ad8d3ecbcaf4778f01e"; 

$twilio = new Client($sid, $token); 
 

	$message = $twilio->messages 
                  ->create($to, // to 
                           array(  
                               "from" => "+16194854852",
							   //"messagingServiceSid" => "SMa7635f97f9434c3b8d142b21b7988cb7",      
                               "body" => $msg 
                           ) 
                  ); 
				  print($message->sid); exit;
	return $message->sid;
}

function whatsapp($msg,$to)
{
	$to='+919659929960';
require_once 'Twilio/autoload.php'; 
$sid    = "AC2792b1671f6922f9cf17dbe56ac0107b"; 
$token  = "1cef381629e66c4a8d44add723fdb4a1"; 
$twilio = new Client($sid, $token);

$message = $twilio->messages
                  ->create("whatsapp:".$to, // to
                           array(
                               "from" => "whatsapp:+14155238886",
                               "body" => "Hi Joe! Thanks for placing an order with us. We’ll let you know once your order has been processed and delivered. Your order number is O12235234"
                           )
                  );

print($message);
}
}*/

require_once 'Twilio/autoload.php';

use Twilio\Rest\Client;
function sendotp($to,$msg)
{
	//$sid    = "AC0cb00021d7054df8989f004397adf52c";
	//$token  = "af9b554af14f1ad8d3ecbcaf4778f01e";
	$sid    = "";
	$token  = "";
	$twilio = new Client($sid, $token);
	
	$message = $twilio->messages
					  ->create($to, // to
							   array(
							   "body" => $msg, "from" => "+16194854852")
					  );
	
	//print($message); exit;
	return $message->sid;
}